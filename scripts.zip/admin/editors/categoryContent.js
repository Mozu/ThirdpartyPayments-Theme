﻿Ext.widget({
    xtype: 'mz-form-categoryPage'
});